#define FRACTION (1<<14)

/*recent CPU*/
int imf(int i, int f){
	return i*f;
}
int fdf(int f1, int f2){
	int64_t tmp = f1;
	tmp *= (FRACTION/2);
	return (int)tmp;
}

/*load_avg*/
